# Foodie_We
FoodieWe is a Food restaurant Website which is made using Reactjs and little Bootstrap 5. It consist of proper navigation and home , about , services and contact section with Some Amazing CSS Animations and properties.

Website is Hosted on this link : https://foodiewe-f6004.web.app/

Some Demo Images :

<img width="960" alt="git1" src="https://user-images.githubusercontent.com/93420193/172604101-02fd51f9-a90f-4fd0-8341-cbcac9e49fba.png">
<img width="960" alt="git2" src="https://user-images.githubusercontent.com/93420193/172604109-0439b57d-0f0a-475d-85a4-0bacba75d061.png">
<img width="960" alt="git3" src="https://user-images.githubusercontent.com/93420193/172604115-123be53a-a03c-4734-ac9a-fe84732eb3e8.png">
<img width="960" alt="git4" src="https://user-images.githubusercontent.com/93420193/172604126-153b4dd8-f255-4ca7-8c92-77b5498eb8b1.png">
<img width="960" alt="git5" src="https://user-images.githubusercontent.com/93420193/172604133-27557ac0-eb16-4e1a-ba1a-39ba77003a96.png">

Demo Video :

https://user-images.githubusercontent.com/93420193/172604253-9e07edba-2887-4a23-9c33-84936e3ac02e.mp4



